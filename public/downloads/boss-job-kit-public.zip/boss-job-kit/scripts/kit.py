"""Package-relative launcher. No private defaults or inherited browser sessions."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import sys
import uuid

ROOT = Path(__file__).resolve().parent.parent
LOCAL = ROOT / '.local'


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(path)


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def local_file(value, must_exist=True):
    if not isinstance(value, str) or not value.strip():
        raise ValueError('Missing local material path')
    path = (LOCAL / value).resolve()
    if not path.is_relative_to(LOCAL.resolve()):
        raise ValueError('Material must be inside this package .local directory')
    if must_exist and not path.is_file():
        raise ValueError('Missing material file: ' + value)
    return path


def profile(complete=False):
    p = read_json(LOCAL / 'profile.json')
    if not p.get('profile_id'):
        raise ValueError('Initialize a new profile first')
    if complete:
        t = p.get('targets', {})
        if not (p.get('display_name') and t.get('roles') and t.get('employment_types')
                and t.get('constraints_confirmed') is True and isinstance(t.get('cities'), list)):
            raise ValueError('Confirm identity, roles, employment types and cities first')
        local_file(p.get('resume_file'))
        f = read_json(local_file(p.get('facts_file')))
        if f.get('profile_id') != p['profile_id'] or f.get('verified_by_user') is not True:
            raise ValueError('Facts must belong to this profile and be checked by this user')
        if not f.get('facts'):
            raise ValueError('No confirmed facts')
        for item in f['facts']:
            if not (item.get('id') and item.get('statement') and item.get('source') and item.get('verified') is True):
                raise ValueError('Each fact needs id, statement, source and verified=true')
        if len({f['id'] for f in f['facts']}) != len(f['facts']):
            raise ValueError('Duplicate fact IDs')
        if p.get('delivery', {}).get('mode') not in ('text_only', 'text_then_image'):
            raise ValueError('Supported modes: text_only / text_then_image')
    return p


def initialize():
    LOCAL.mkdir(exist_ok=True)
    # Exclusive creation protects existing users from an accidental reset.
    with (LOCAL / 'profile.json').open('x', encoding='utf-8') as out:
        p = read_json(ROOT / 'templates/profile.example.json')
        p['profile_id'] = str(uuid.uuid4())
        json.dump(p, out, ensure_ascii=False, indent=2)
    for template, target in [('facts.example.json', 'facts.json'), ('history.example.json', 'history.json')]:
        data = read_json(ROOT / 'templates' / template)
        data['profile_id'] = p['profile_id']
        write_json(LOCAL / target, data)
    for folder in ('materials', 'queue', 'attempts', 'ledger', 'search_results'):
        (LOCAL / folder).mkdir(exist_ok=True)
    return {'initialized': True, 'profile_id': p['profile_id'], 'profile': str(LOCAL / 'profile.json')}


def bind_environment():
    profile()
    # Do not silently inherit another installation's authentication or data paths.
    os.environ.pop('BOSS_CDP_URL', None)
    os.environ['BOSS_DATA_DIR'] = str(LOCAL)
    os.environ['BOSS_COOKIES_PATH'] = str(LOCAL / 'cookies' / 'cookies.json')
    os.environ['PYTHONUTF8'] = '1'
    return LOCAL


def configuration():
    profile()
    servers = {}
    for label, action in [('boss-agent', 'mcp'), ('job-ledger', 'ledger')]:
        servers[label] = {'command': str(Path(sys.executable).resolve()),
                          'args': ['-u', str(Path(__file__).resolve()), action],
                          'env': {'PYTHONUTF8': '1'}}
    path = LOCAL / 'mcp-config.json'
    write_json(path, {'mcpServers': servers})
    return {'config_file': str(path), 'global_config_changed': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['init', 'check', 'config', 'login', 'mcp', 'ledger', 'send'])
    parser.add_argument('--plan')
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--authorization')
    args = parser.parse_args()
    if args.action == 'init':
        result = initialize()
    elif args.action == 'check':
        p = profile(complete=True)
        result = {'ready_for_planning': True, 'profile_id': p['profile_id'], 'browser_tested': False}
    elif args.action == 'config':
        result = configuration()
    elif args.action == 'send':
        from sender import send
        if not args.plan:
            parser.error('--plan required')
        result = send(Path(args.plan), execute=args.execute, authorization=args.authorization)
    else:
        bind_environment()
        runtime = ROOT / 'runtime' / 'boss-agent'
        sys.path.insert(0, str(runtime))
        if args.action == 'ledger':
            target = ROOT / 'runtime' / 'job-ledger' / 'server.py'
            sys.argv = [str(target), '--data-dir', str(LOCAL / 'ledger')]
        elif args.action == 'login':
            target = runtime / 'login_native.py'
            sys.argv = [str(target)]
        else:
            target = runtime / 'main.py'
            sys.argv = [str(target), '--transport', 'stdio', '--headless']
        runpy.run_path(str(target), run_name='__main__')
        return
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
