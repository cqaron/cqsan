"""Explicit prepared-plan sender. Default preflight never opens a browser."""
from datetime import datetime, timezone, timedelta
from contextlib import closing
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import struct
import sys
import time
from urllib.parse import urlsplit

import kit


def job_key(url):
    p = urlsplit(url)
    if (p.scheme != 'https' or p.hostname != 'www.zhipin.com' or p.username or p.password
            or p.port not in (None, 443) or not re.fullmatch(r'/job_detail/[A-Za-z0-9_-]+\.html', p.path)):
        raise ValueError('Expected a BOSS job detail URL')
    return p.path


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(',', ':')).encode()).hexdigest()


def image_dimensions(path):
    """Read PNG/JPEG dimensions without a new image-processing dependency."""
    b = path.read_bytes()
    if b.startswith(b'\x89PNG\r\n\x1a\n') and len(b) >= 24 and b[12:16] == b'IHDR':
        dims = struct.unpack('>II', b[16:24])
    elif b.startswith(b'\xff\xd8'):
        pos = 2
        dims = None
        while pos < len(b):
            if b[pos] != 255:
                raise ValueError('Malformed JPEG')
            while pos < len(b) and b[pos] == 255:
                pos += 1
            marker = b[pos]
            pos += 1
            if marker in (0xD9, 0xDA):
                break
            if marker == 0x01 or 0xD0 <= marker <= 0xD7:
                continue
            length = struct.unpack('>H', b[pos:pos + 2])[0]
            if length < 2:
                raise ValueError('Malformed JPEG segment')
            if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                height, width = struct.unpack('>HH', b[pos + 3:pos + 7])
                dims = (width, height)
                break
            pos += length
        if dims is None:
            raise ValueError('JPEG dimensions not found')
    else:
        raise ValueError('Resume image must be a real PNG or JPEG')
    if min(dims) <= 0:
        raise ValueError('Invalid image size')
    return dims


def duplicate(plan, row):
    job = plan['job']
    url = row.get('job_url') or row.get('url') or row.get('job', {}).get('url')
    same_url = False
    if url:
        try:
            same_url = job_key(url) == job_key(job['url'])
        except ValueError:
            pass
    r = row.get('job', row)
    norm = lambda s: re.sub(r'\s+', '', s or '').casefold()
    same_company = norm(r.get('company')) == norm(job['company'])
    return same_url or (same_company and (
        norm(r.get('title')) == norm(job['title']) or
        (r.get('contact') and norm(r['contact']) == norm(job['contact']))))


def check_duplicates(plan, p):
    h = kit.read_json(kit.LOCAL / 'history.json')
    if h.get('profile_id') != p['profile_id']:
        raise ValueError('History belongs to another profile')
    rows = list(h.get('records', []))
    for path in (kit.LOCAL / 'attempts').glob('*.json'):
        rows.append(kit.read_json(path))
    database = kit.LOCAL / 'ledger' / 'jobs.sqlite3'
    if database.is_file():
        with closing(sqlite3.connect(database)) as db:
            db.row_factory = sqlite3.Row
            rows.extend(dict(r) for r in db.execute("SELECT company,title,url FROM jobs WHERE status NOT IN ('saved','to_apply')"))
    if any(duplicate(plan, row) for row in rows):
        raise ValueError('Prior contact or attempt exists; reconcile instead of retrying')


def preflight(plan):
    p = kit.profile(complete=True)
    if plan.get('profile_id') != p['profile_id']:
        raise ValueError('Plan belongs to another user profile')
    job = plan.get('job', {})
    for field in ('url', 'company', 'title', 'contact'):
        if not isinstance(job.get(field), str) or not job[field].strip():
            raise ValueError('Missing job identity: ' + field)
    key = job_key(job['url'])
    if not plan.get('jd') or not plan.get('jd_checked_at'):
        raise ValueError('Read and archive the JD before sending')
    stamp = datetime.fromisoformat(plan['jd_checked_at'].replace('Z', '+00:00'))
    if stamp.tzinfo is None or not timedelta(0) <= datetime.now(timezone.utc) - stamp <= timedelta(days=1):
        raise ValueError('JD evidence must be within 24 hours; recheck the live listing')
    if plan.get('eligibility', {}).get('status') != 'eligible' or not plan['eligibility'].get('evidence'):
        raise ValueError('Job eligibility not verified')
    if not plan.get('requirement_matches'):
        raise ValueError('Analyze JD requirements first')
    facts = kit.read_json(kit.local_file(p['facts_file']))
    ids = {f['id'] for f in facts['facts']}
    if not plan.get('fact_ids') or not set(plan['fact_ids']).issubset(ids):
        raise ValueError('Introduction references missing facts')
    msg = plan.get('message', '')
    if not isinstance(msg, str) or not msg.strip() or len(msg) > p['writing']['max_characters']:
        raise ValueError('Message empty or longer than user configuration')
    check_duplicates(plan, p)
    image = None
    dims = None
    digest = None
    if p['delivery']['mode'] == 'text_then_image':
        image = kit.local_file(p.get('resume_image'))
        if image.suffix.lower() not in ('.jpg', '.jpeg', '.png'):
            raise ValueError('Only PNG/JPEG resumes can be sent as images')
        dims = image_dimensions(image)
        digest = hashlib.sha256(image.read_bytes()).hexdigest()
        if digest != plan.get('resume_sha256'):
            raise ValueError('Resume image changed or was not checked')
    # Bind approval to the plan, exact profile, confirmed facts and chosen material.
    approval_hash = fingerprint({'plan': plan, 'profile': p, 'facts': facts, 'image_sha256': digest})
    return p, {'status': 'dry_run', 'plan_sha256': approval_hash,
               'job_key': key, 'image_dimensions': dims, 'resume_sha256': digest}, image


def authorize(path, p, digest):
    a = kit.read_json(path)
    if (a.get('profile_id') != p['profile_id'] or a.get('approved_by_user') is not True
            or not a.get('instruction_quote', '').strip() or a.get('account_checked') is not True
            or not a.get('account_check_note', '').strip() or digest not in a.get('plan_sha256', [])):
        raise ValueError('Missing current user, account or exact-plan authorization')
    expires = datetime.fromisoformat(a['expires_at'].replace('Z', '+00:00'))
    if expires.tzinfo is None or not timedelta(0) < expires - datetime.now(timezone.utc) <= timedelta(days=1):
        raise ValueError('Authorization expired or beyond 24 hours')
    return a


def wait(s, expr, seconds=12):
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        value = s.evaluate(expr)
        if value:
            return value
        time.sleep(.25)
    raise RuntimeError('Page evidence not confirmed; do not automatically resend')


def perform(s, plan, image, dimensions, save):
    """Keep DOM interactions narrow; fail closed when website shape changes."""
    job, message = plan['job'], plan['message']
    s.navigate(job['url'])
    wait(s, 'document.body.innerText.includes(' + json.dumps(job['title']) + ')')
    before = s.evaluate('({url:location.href,text:document.body.innerText})')
    if job_key(before['url']) != job_key(job['url']) or not all(job[f] in before['text'] for f in ('company', 'title', 'contact')):
        raise RuntimeError('Wrong live job or recipient')
    state = s.evaluate("(()=>{let e=[...document.querySelectorAll('.btn-startchat')].find(e=>e.offsetWidth);return {text:e?.innerText.trim(),friend:e?.getAttribute('data-isfriend'),route:e?.getAttribute('redirect-url')}})()")
    route = state.get('route', '')
    if state.get('text') != '立即沟通' or state.get('friend') == 'true' or not route.startswith('/web/geek/chat?'):
        raise RuntimeError('Prior contact or unexpected chat action; inspect manually')
    save('opening_chat', jd_before=before)
    s.evaluate("[...document.querySelectorAll('.btn-startchat')].find(e=>e.offsetWidth).click()")
    wait(s, "document.querySelector('.startchat-dialog textarea')?.offsetWidth")
    heading = s.evaluate("document.querySelector('.startchat-title').innerText")
    if not all(job[f] in heading for f in ('contact', 'company')):
        raise RuntimeError('Unexpected chat recipient')
    if s.evaluate("document.querySelector('.startchat-dialog .message-list').innerText.trim()"):
        raise RuntimeError('Existing conversation; do not append automatically')
    s.evaluate('(()=>{let e=document.querySelector(".startchat-dialog textarea");e.value=' + json.dumps(message) + ';e.dispatchEvent(new Event("input",{bubbles:true}));return e.value})()')
    if s.evaluate("document.querySelector('.startchat-dialog textarea').value") != message:
        raise RuntimeError('Message input changed')
    save('text_send_attempt')
    s.evaluate("(()=>{let e=document.querySelector('.startchat-dialog .send-message');if(!e||e.classList.contains('disable'))throw Error('send unavailable');e.click()})()")
    wait(s, '(()=>{let e=document.querySelector(".startchat-dialog");return e?.innerText.includes("已发送")&&e.innerText.replace(/\\s/g,"").includes(' + json.dumps(''.join(message.split())) + ')})()')
    s.navigate('https://www.zhipin.com' + route)
    wait(s, 'document.body.innerText.includes(' + json.dumps(message) + ')&&!!document.querySelector("#chat-input")')
    tail = s.evaluate('document.body.innerText.slice(-5000)')
    if job['title'] not in tail or job['contact'] not in tail:
        raise RuntimeError('Selected chat identity not confirmed')
    wait(s, '[...document.querySelectorAll(".message-status.status-delivery")].some(e=>e.parentElement.innerText.replace(/\\s/g,"").includes(' + json.dumps(''.join(message.split())) + '))')
    save('text_delivered', text_status='送达')
    if image:
        if s.evaluate("document.querySelectorAll('.message-image').length"):
            raise RuntimeError('Prior image exists; inspect before uploading')
        root = s.call('DOM.getDocument')['root']['nodeId']
        node = s.call('DOM.querySelector', {'nodeId': root, 'selector': 'input[accept="image/gif,image/jpeg,image/jpg,image/png"]'})['nodeId']
        if not node:
            raise RuntimeError('Image upload control unavailable')
        save('image_send_attempt')
        s.call('DOM.setFileInputFiles', {'nodeId': node, 'files': [str(image)]})
        w, h = dimensions
        wait(s, "(()=>{let e=document.querySelector('.message-image');return e?.complete&&e.naturalWidth===" + str(w) + "&&e.naturalHeight===" + str(h) + "&&e.closest('.item-image')?.innerText.includes('送达')})()", 20)
        save('image_delivered', image_status='送达')
    evidence = s.evaluate('({url:location.href,text:document.body.innerText.slice(-5000),images:[...document.querySelectorAll(".message-image")].map(e=>({width:e.naturalWidth,height:e.naturalHeight,loaded:e.complete}))})')
    save('delivered', evidence=evidence)


def send(path, execute=False, authorization=None, session_factory=None):
    plan = kit.read_json(path)
    p, result, image = preflight(plan)
    if not execute:
        return result
    if not authorization:
        raise ValueError('Execution requires this user current authorization record')
    a = authorize(authorization, p, result['plan_sha256'])
    kit.bind_environment()
    lock = kit.LOCAL / 'browser.lock'
    with lock.open('x', encoding='utf-8') as out:
        import os
        out.write(str(os.getpid()))
    try:
        # Recheck while holding the only browser lock.
        check_duplicates(plan, p)
        path = kit.LOCAL / 'attempts' / (fingerprint(result['job_key']) + '.json')
        record = {'profile_id': p['profile_id'], 'job': plan['job'], 'message': plan['message'],
                  'resume_sha256': result['resume_sha256'], 'plan_sha256': result['plan_sha256'],
                  'authorization': a, 'status': 'claimed', 'started_at': datetime.now(timezone.utc).isoformat()}
        with path.open('x', encoding='utf-8') as out:
            json.dump(record, out, ensure_ascii=False, indent=2)

        def save(status, **details):
            record.update(details)
            record['status'] = status
            record['updated_at'] = datetime.now(timezone.utc).isoformat()
            kit.write_json(path, record)

        try:
            if session_factory is None:
                sys.path.insert(0, str(kit.ROOT / 'runtime' / 'boss-agent'))
                from browser.native_cdp import NativeBossSession
                session_factory = NativeBossSession
            with session_factory() as session:
                perform(session, plan, image, result['image_dimensions'], save)
        except BaseException as error:
            save('interrupted', last_stage=record['status'], error=str(error))
            raise
        return {'status': record['status'], 'text': record.get('text_status'),
                'image': record.get('image_status'), 'attempt': str(path), 'ledger_sync_required': True}
    finally:
        lock.unlink()
