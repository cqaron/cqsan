"""Export reviewed distribution files only; never discover runtime user data."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent.parent
ALLOWED = {'README.md', 'AGENTS.md', '.gitignore', 'docs', 'templates', 'scripts', 'runtime', 'skills', 'tests'}
BLOCKED = {'.local', '.venv', 'cookies', 'search_results', '__pycache__', '.browser-profile', '.git', 'dist'}


def export(root=ROOT, output=None):
    root = Path(root).resolve()
    manifest = json.loads((root / 'release-manifest.json').read_text(encoding='utf-8'))
    payload = {}
    for name, expected in manifest['files'].items():
        path = Path(name)
        if (path.is_absolute() or '..' in path.parts or not path.parts or path.parts[0] not in ALLOWED
                or BLOCKED.intersection(path.parts) or path.suffix.lower() in ('.sqlite3', '.db', '.jpg', '.jpeg', '.png', '.docx', '.env')):
            raise ValueError('Non-distribution path rejected: ' + name)
        full = (root / path).resolve()
        if not full.is_relative_to(root):
            raise ValueError('Path escapes package')
        data = full.read_bytes()
        if hashlib.sha256(data).hexdigest() != expected:
            raise ValueError('Reviewed file changed; review before updating manifest: ' + name)
        payload[name] = data
    output = Path(output) if output else root / 'dist' / 'boss-job-kit-public.zip'
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as out:
        for name, data in payload.items():
            out.writestr('boss-job-kit/' + name, data)
        out.writestr('boss-job-kit/release-manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
    with zipfile.ZipFile(output) as check:
        if check.testzip() is not None:
            raise ValueError('ZIP integrity check failed')
    return {'zip': str(output), 'file_count': len(payload) + 1,
            'sha256': hashlib.sha256(output.read_bytes()).hexdigest()}


if __name__ == '__main__':
    print(json.dumps(export(), ensure_ascii=False, indent=2))
