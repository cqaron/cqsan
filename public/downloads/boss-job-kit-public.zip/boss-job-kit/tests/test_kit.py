"""Offline behavior checks. Never connects to Chrome or sends messages."""
from datetime import datetime, timedelta, timezone
from contextlib import closing
import hashlib
import os
import json
from pathlib import Path
import sqlite3
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'scripts'))
import kit
import sender
import export_public


class KitTest(unittest.TestCase):
    def setUp(self):
        (ROOT / '.test-work').mkdir(exist_ok=True)
        self.temp = tempfile.TemporaryDirectory(dir=ROOT / '.test-work')
        self.local = Path(self.temp.name) / '.local'
        self.binding = patch.object(kit, 'LOCAL', self.local)
        self.binding.start()
        self.addCleanup(self.binding.stop)
        self.addCleanup(self.temp.cleanup)
        kit.initialize()
        self.p = kit.profile()
        self.p.update(display_name='Example applicant', resume_file='materials/resume.txt')
        self.p['targets'].update(roles=['product operations'], employment_types=['full_time'],
                                 cities=[], constraints_confirmed=True)
        self.p['delivery']['mode'] = 'text_only'
        kit.write_json(self.local / 'profile.json', self.p)
        (self.local / 'materials/resume.txt').write_text('Fictional test material', encoding='utf-8')
        kit.write_json(self.local / 'facts.json', {'profile_id': self.p['profile_id'],
            'verified_by_user': True, 'facts': [{'id': 'fact-a', 'statement': 'Fictional test fact',
                                                'source': 'materials/resume.txt', 'verified': True}]})
        self.plan = {'profile_id': self.p['profile_id'],
            'job': {'url': 'https://www.zhipin.com/job_detail/testjob.html', 'company': 'Fictional employer',
                    'title': 'Example role', 'contact': 'Example recruiter'},
            'jd': 'Fictional JD for offline tests', 'jd_checked_at': datetime.now(timezone.utc).isoformat(),
            'eligibility': {'status': 'eligible', 'evidence': 'Fictional eligibility'},
            'requirement_matches': [{'requirement': 'Fictional requirement', 'fact_ids': ['fact-a']}],
            'fact_ids': ['fact-a'], 'message': 'Fictional introduction for an offline test only.', 'resume_sha256': ''}
        self.plan_path = self.local / 'queue/test.json'
        kit.write_json(self.plan_path, self.plan)

    def authorization(self):
        digest = sender.preflight(self.plan)[1]['plan_sha256']
        a = {'profile_id': self.p['profile_id'], 'approved_by_user': True,
             'instruction_quote': 'Fictional offline test authorization', 'account_checked': True,
             'account_check_note': 'Fake browser only', 'plan_sha256': [digest],
             'expires_at': (datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat()}
        path = self.local / 'authorization.json'
        kit.write_json(path, a)
        return path

    def test_init_cannot_replace_existing_person(self):
        with self.assertRaises(FileExistsError):
            kit.initialize()

    def test_unknown_preferences_block_readiness(self):
        self.p['targets']['cities'] = None
        kit.write_json(self.local / 'profile.json', self.p)
        with self.assertRaisesRegex(ValueError, 'Confirm'):
            kit.profile(complete=True)

    def test_material_cannot_escape_profile(self):
        with self.assertRaises(ValueError):
            kit.local_file('../someone-else.txt')

    def test_dry_run_never_creates_browser_or_attempt(self):
        def forbidden():
            self.fail('Dry-run attempted a browser connection')
        result = sender.send(self.plan_path, session_factory=forbidden)
        self.assertEqual(result['status'], 'dry_run')
        self.assertEqual(list((self.local / 'attempts').iterdir()), [])

    def test_other_user_and_invented_facts_blocked(self):
        self.plan['profile_id'] = 'another-person'
        with self.assertRaises(ValueError):
            sender.preflight(self.plan)
        self.plan['profile_id'] = self.p['profile_id']
        self.plan['fact_ids'] = ['nonexistent']
        with self.assertRaises(ValueError):
            sender.preflight(self.plan)

    def test_execute_without_authorization_blocked(self):
        with self.assertRaisesRegex(ValueError, 'requires'):
            sender.send(self.plan_path, execute=True)

    def test_authorization_invalid_after_plan_or_profile_change(self):
        a = self.authorization()
        self.plan['message'] += ' changed'
        new = sender.preflight(self.plan)[1]['plan_sha256']
        with self.assertRaises(ValueError):
            sender.authorize(a, self.p, new)
        self.plan['message'] = self.plan['message'].removesuffix(' changed')
        self.p['writing']['omit'] = ['example field']
        kit.write_json(self.local / 'profile.json', self.p)
        with self.assertRaises(ValueError):
            sender.authorize(a, self.p, sender.preflight(self.plan)[1]['plan_sha256'])

    def test_expired_authorization_blocked(self):
        a = self.authorization()
        data = kit.read_json(a)
        data['expires_at'] = (datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat()
        kit.write_json(a, data)
        with self.assertRaises(ValueError):
            sender.authorize(a, self.p, data['plan_sha256'][0])

    def test_history_checks_url_variants_and_same_recipient(self):
        history = kit.read_json(self.local / 'history.json')
        history['records'] = [dict(self.plan['job'], url=self.plan['job']['url'] + '?query=variant')]
        kit.write_json(self.local / 'history.json', history)
        with self.assertRaises(ValueError):
            sender.preflight(self.plan)
        history['records'][0]['url'] = 'https://www.zhipin.com/job_detail/another.html'
        history['records'][0]['title'] = 'Another role'
        kit.write_json(self.local / 'history.json', history)
        with self.assertRaises(ValueError):
            sender.preflight(self.plan)

    def test_applied_ledger_blocks_send(self):
        with closing(sqlite3.connect(self.local / 'ledger/jobs.sqlite3')) as db:
            db.execute('CREATE TABLE jobs(company TEXT,title TEXT,url TEXT,status TEXT)')
            j = self.plan['job']
            db.execute('INSERT INTO jobs VALUES(?,?,?,?)', (j['company'], j['title'], j['url'], 'applied'))
            db.commit()
        with self.assertRaises(ValueError):
            sender.preflight(self.plan)

    def test_image_dimensions_not_tied_to_one_resume(self):
        image = self.local / 'materials/resume.png'
        image.write_bytes(b'\x89PNG\r\n\x1a\n' + struct.pack('>I', 13) + b'IHDR' + struct.pack('>II', 900, 1200))
        self.p['delivery']['mode'] = 'text_then_image'
        self.p['resume_image'] = 'materials/resume.png'
        kit.write_json(self.local / 'profile.json', self.p)
        self.plan['resume_sha256'] = hashlib.sha256(image.read_bytes()).hexdigest()
        self.assertEqual(sender.preflight(self.plan)[1]['image_dimensions'], (900, 1200))
        image.write_bytes(image.read_bytes() + b'changed')
        with self.assertRaisesRegex(ValueError, 'changed'):
            sender.preflight(self.plan)

    def test_interrupt_journal_prevents_resend(self):
        auth = self.authorization()
        class FakeSession:
            def __enter__(self):
                raise RuntimeError('Fictional browser failure')
            def __exit__(self, *args):
                pass
        with self.assertRaises(RuntimeError):
            sender.send(self.plan_path, execute=True, authorization=auth, session_factory=FakeSession)
        records = list((self.local / 'attempts').glob('*.json'))
        self.assertEqual(len(records), 1)
        self.assertEqual(kit.read_json(records[0])['status'], 'interrupted')
        self.assertFalse((self.local / 'browser.lock').exists())
        with self.assertRaisesRegex(ValueError, 'Prior contact'):
            sender.send(self.plan_path)

    def test_existing_browser_lock_blocks_execution(self):
        auth = self.authorization()
        (self.local / 'browser.lock').write_text('fake process')
        with self.assertRaises(FileExistsError):
            sender.send(self.plan_path, execute=True, authorization=auth)

    def test_bind_discards_host_authentication(self):
        with patch.dict(os.environ, {'BOSS_CDP_URL': 'http://other-host:1234', 'BOSS_COOKIES_PATH': '/other/cookies'}):
            kit.bind_environment()
            self.assertNotIn('BOSS_CDP_URL', os.environ)
            self.assertEqual(os.environ['BOSS_DATA_DIR'], str(self.local))

    def test_wrong_live_recipient_does_not_open_chat(self):
        plan = self.plan
        calls = []
        class WrongRecipient:
            def navigate(self, url):
                calls.append(('navigate', url))
            def evaluate(self, expr):
                calls.append(('evaluate', expr))
                if expr.startswith('({url:'):
                    return {'url': plan['job']['url'], 'text': plan['job']['title'] + ' Wrong company'}
                return True
        with self.assertRaisesRegex(RuntimeError, 'recipient'):
            sender.perform(WrongRecipient(), plan, None, None, lambda *a, **kw: None)
        self.assertFalse(any('.click()' in value for _, value in calls))

    def test_text_only_success_has_verified_state_and_blocks_second_send(self):
        plan = self.plan
        auth = self.authorization()
        seen = []
        class FakeSession:
            def __enter__(self):
                return self
            def __exit__(self, *args):
                pass
            def navigate(self, url):
                seen.append(url)
            def evaluate(self, expr):
                seen.append(expr)
                if expr == '({url:location.href,text:document.body.innerText})':
                    return {'url': plan['job']['url'], 'text': ' '.join(plan['job'].values())}
                if 'return {text:e?' in expr:
                    return {'text': '立即沟通', 'friend': 'false', 'route': '/web/geek/chat?recipient=fake'}
                if expr == "document.querySelector('.startchat-title').innerText":
                    return plan['job']['company'] + plan['job']['contact']
                if expr == "document.querySelector('.startchat-dialog .message-list').innerText.trim()":
                    return ''
                if expr == "document.querySelector('.startchat-dialog textarea').value":
                    return plan['message']
                if expr == 'document.body.innerText.slice(-5000)':
                    return plan['job']['title'] + plan['job']['contact']
                if expr.startswith('({url:'):
                    return {'url': 'https://www.zhipin.com/web/geek/chat?recipient=fake', 'text': plan['message'], 'images': []}
                return True
            def call(self, *args):
                raise AssertionError('Text-only mode must not upload any file')
        result = sender.send(self.plan_path, execute=True, authorization=auth, session_factory=FakeSession)
        self.assertEqual(result['status'], 'delivered')
        self.assertEqual(result['text'], '送达')
        self.assertIsNone(result['image'])
        self.assertTrue(any('status-delivery' in item for item in seen))
        with self.assertRaisesRegex(ValueError, 'Prior contact'):
            sender.send(self.plan_path)

    def test_export_never_includes_runtime_and_rejects_changed_source(self):
        stage = Path(self.temp.name) / 'release'
        (stage / '.local').mkdir(parents=True)
        (stage / '.local/secret.txt').write_text('PRIVATE TEST MARKER')
        (stage / 'README.md').write_text('public')
        digest = hashlib.sha256((stage / 'README.md').read_bytes()).hexdigest()
        kit.write_json(stage / 'release-manifest.json', {'files': {'README.md': digest}})
        out = stage / 'dist/test.zip'
        export_public.export(stage, out)
        with zipfile.ZipFile(out) as archive:
            self.assertFalse(any('.local' in n for n in archive.namelist()))
        (stage / 'README.md').write_text('changed')
        with self.assertRaisesRegex(ValueError, 'changed'):
            export_public.export(stage, out)
        kit.write_json(stage / 'release-manifest.json', {'files': {'.local/secret.txt': 'ignored'}})
        with self.assertRaisesRegex(ValueError, 'rejected'):
            export_public.export(stage, out)

    def test_ledger_mcp_starts_empty_and_has_no_preset_companies(self):
        requests = [
            {'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {'protocolVersion': '2024-11-05'}},
            {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/list'},
            {'jsonrpc': '2.0', 'id': 3, 'method': 'tools/call', 'params': {'name': 'health_check', 'arguments': {}}}]
        data = '\n'.join(json.dumps(r) for r in requests) + '\n'
        process = subprocess.run([sys.executable, str(ROOT / 'runtime/job-ledger/server.py'), '--data-dir',
                                  str(self.local / 'ledger')], input=data, encoding='utf-8',
                                 capture_output=True, timeout=15, check=True)
        replies = [json.loads(line) for line in process.stdout.splitlines()]
        self.assertEqual(len(replies[1]['result']['tools']), 9)
        health = replies[2]['result']['structuredContent']
        self.assertEqual(health['job_count'], 0)
        self.assertEqual(health['preset_companies'], [])

    def test_image_upload_occurs_only_after_text_delivery(self):
        plan = self.plan
        stages = []
        uploaded = []
        class FakeSession:
            def navigate(self, url):
                pass
            def evaluate(self, expr):
                if expr == '({url:location.href,text:document.body.innerText})':
                    return {'url': plan['job']['url'], 'text': ' '.join(plan['job'].values())}
                if 'return {text:e?' in expr:
                    return {'text': '立即沟通', 'friend': 'false', 'route': '/web/geek/chat?recipient=fake'}
                if expr == "document.querySelector('.startchat-title').innerText":
                    return plan['job']['company'] + plan['job']['contact']
                if expr == "document.querySelector('.startchat-dialog .message-list').innerText.trim()":
                    return ''
                if expr == "document.querySelector('.startchat-dialog textarea').value":
                    return plan['message']
                if expr == 'document.body.innerText.slice(-5000)':
                    return plan['job']['title'] + plan['job']['contact']
                if expr == "document.querySelectorAll('.message-image').length":
                    return 0
                if expr.startswith('({url:'):
                    return {'text': plan['message']}
                if 'naturalWidth===' in expr:
                    if 'naturalWidth===700' not in expr or 'naturalHeight===1000' not in expr:
                        raise AssertionError('Wrong dynamic image dimensions')
                return True
            def call(self, method, params=None):
                if method == 'DOM.getDocument':
                    return {'root': {'nodeId': 1}}
                if method == 'DOM.querySelector':
                    return {'nodeId': 2}
                if method == 'DOM.setFileInputFiles':
                    if 'text_delivered' not in stages or stages[-1] != 'image_send_attempt':
                        raise AssertionError('Image uploaded before confirmed text')
                    uploaded.extend(params['files'])
                    return {}
                raise AssertionError('Unexpected method')
        sender.perform(FakeSession(), plan, self.local / 'materials/example.png', (700, 1000),
                       lambda status, **details: stages.append(status))
        self.assertEqual(stages[-2:], ['image_delivered', 'delivered'])
        self.assertEqual(len(uploaded), 1)


if __name__ == '__main__':
    unittest.main(verbosity=2)
