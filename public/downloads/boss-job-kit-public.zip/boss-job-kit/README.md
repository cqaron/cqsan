# BOSS 求职助手 · 通用资源包

把此文件夹交给支持本地文件、Python 和浏览器工具的 Agent，并发送：

> 请先读 AGENTS.md，帮我初始化个人档案，核实所需材料。先模拟筛选与定制介绍，展示岗位 JD、匹配依据和消息草稿；未经我本次授权不要发送。

包内没有任何求职者档案、简历、历史岗位、投递记录或浏览器登录状态。它是一套可由 Agent 使用和修改的源码、Skill、配置模板与运行脚本，不需要 EXE。

## 首次使用

1. 提供最新版简历；需要发送简历图片时另提供 JPG/PNG。可选提供个人介绍、作品集链接及可引用项目。先由 Agent 提取事实并让本人核对。
2. 说明目标岗位、城市、工作性质、可入职时间或毕业时间、硬性排除项、已沟通过的公司/岗位。没有限制可明确填“不限”，不从他人的档案继承偏好。
3. 在此目录执行 `powershell -ExecutionPolicy Bypass -File scripts/setup.ps1`。需要 Python 3.11+、系统 Chrome；安装依赖需要网络。当前安装脚本面向 Windows，原生 Chrome 路径查找也面向 Windows。
4. 执行 `.venv/Scripts/python.exe scripts/kit.py init`。它建立全新的 `.local` 私人目录，不会自动搜索电脑里的简历或导入其他 MCP 的历史库。参考 `templates/profile.example.json` 编辑 `.local/profile.json`，把材料放进 `.local/materials/`。配置中所有文件路径相对 `.local/`。
5. 把简历中的可用事实整理成 `.local/facts.json`；每条包含来源与本人核实标记。执行 `... scripts/kit.py check` 检查档案。模拟可使用已提取的文本，发送图片前会额外验证图片格式和文件哈希。
6. 执行 `... scripts/kit.py config`，将输出的 `.local/mcp-config.json` 中两个 MCP 项合并到所用 Agent 的配置；脚本不改全局配置。配置使用绝对路径，搬家后重跑。Agent 若支持 Skill，可安装或直接读取 `skills/boss-job-assistant/SKILL.md`。
7. 执行 `... scripts/kit.py login`，在新建的专用 Chrome 完成自己的登录，再回终端按 Enter。随后让 Agent 检查登录状态。后续保留此窗口，只让一个执行者操作它。

上文 `...` 表示此目录的 `.venv/Scripts/python.exe`。不必下载 Playwright 的 Chromium：默认走系统 Chrome 原生 CDP；保留 Playwright 库是为兼容底层导入。

## 能力与边界

| 环节 | 实现 |
|---|---|
| 搜索、JD、登录状态 | BOSS MCP + 系统 Chrome 原生 CDP；默认只有读取工具 |
| 匹配、文案 | Agent 按 Skill 从当前用户事实出发判断，不调用固定个人模板 |
| 岗位台账 | 独立本地 SQLite MCP，只有当前包 `.local/ledger` 的数据 |
| 先文字后简历图片 | `scripts/kit.py send` 调用原生 CDP 发送器；默认只检查，不连接浏览器 |
| 去重与核验 | URL 岗位 ID、岗位信息、联系人检查；操作前留档，文字与图片分别核验；不明结果不自动重试 |

当前发送能力以 Agent 调用本地脚本衔接，**没有宣称原生发送已经封装为 MCP 单工具**。原始 `apply_job` 工具在此版本关闭，避免绕过本包的授权与去重。网页 DOM 改版时可能需调整选择器；未在新用户账号上完成实投验收。

模拟：`... scripts/kit.py send --plan .local/queue/job.json`

实际发送：先按 `docs/执行与状态.md` 生成本次限时授权记录，然后加 `--execute --authorization .local/authorization.json`。一次只处理一个岗位。授权记录必须来自用户本次真实指令，不能由 Agent 自行编造。批次允许时可逐条调用，不必逐条重复询问。

## 如何修改与分享

- 只改方向/城市/排除项/介绍长度：改 `.local/profile.json`。
- 改筛选、JD 拆解、文案风格：改 Skill 及其 `references/`。
- 加平台动作或 MCP 工具：改 `runtime/boss-agent/`，同时补核验与回归测试。
- 加初始化、导出或文件处理：改 `scripts/`。
- 已有沟通要去重：首次使用时将本人历史导入台账和 `.local/history.json`，参见状态文档；系统不能推测别处账号记录。

分享前执行 `... scripts/export_public.py`。它按发行清单白名单打包，并校验发行文件哈希；不打包 `.local`、环境、浏览器资料或任意新增文件。修改源码后需审查变化并显式更新发行清单。**不要直接压缩使用后的整个目录。**

依赖与源码说明见 `docs/架构与扩展.md`；空白模板见 `templates/`。本包不包含 Agent 模型，模型与使用额度由接手者的环境提供。
