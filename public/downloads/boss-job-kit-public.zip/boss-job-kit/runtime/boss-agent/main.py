"""Local MCP entry point; stdio is the default for Codex."""
import argparse
from server.tools import create_mcp_server


def main():
    parser = argparse.ArgumentParser(description="Boss MCP")
    parser.add_argument("--transport", choices=["stdio", "streamable-http"], default="stdio")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", "-p", type=int, default=18061)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--headless", dest="headless", action="store_true")
    group.add_argument("--no-headless", dest="headless", action="store_false")
    parser.set_defaults(headless=True)
    args = parser.parse_args()
    mcp = create_mcp_server(headless=args.headless)
    if args.transport == "stdio":
        mcp.run(transport="stdio", show_banner=False)
    else:
        mcp.run(transport=args.transport, host=args.host, port=args.port, stateless_http=True)


if __name__ == "__main__":
    main()
