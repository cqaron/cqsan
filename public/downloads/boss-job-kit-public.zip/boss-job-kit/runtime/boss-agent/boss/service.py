"""Service layer for Boss直聘 MCP — bridges browser actions to MCP tools."""

from __future__ import annotations

import time
from urllib.parse import urlsplit
from pathlib import Path

from loguru import logger

from browser.manager import create_browser, save_browser_cookies, get_cdp_url
from boss.actions import (
    LoginAction,
    CheckLoginAction,
    JobSearchAction,
    JobDetailAction,
    ApplyJobAction,
    AnalyzeJobAction,
)


class BossService:
    """High-level operations for Boss直聘 automation."""

    @staticmethod
    def _sanitize_filename(name: str, max_len: int = 50) -> str:
        """Sanitize a string for use as a filename."""
        invalid_chars = '<>:"/\\|?*\n\r\t'
        for ch in invalid_chars:
            name = name.replace(ch, "_")
        return name.strip(" .")[:max_len] or "untitled"

    @staticmethod
    def _validate_job_url(url: str) -> None:
        parsed = urlsplit(url)
        if (parsed.scheme != "https" or parsed.hostname != "www.zhipin.com"
                or parsed.username or parsed.password or parsed.port not in (None, 443)
                or not parsed.path.startswith("/job_detail/")):
            raise ValueError("需要 https://www.zhipin.com/job_detail/ 下的岗位链接")

    # --- Login ---

    def login_wait(self, headless: bool = True, timeout: int = 240) -> dict:
        """Open browser, show QR code, wait for user to scan."""
        with create_browser(headless=headless) as (browser, context, page):
            action = LoginAction(page, context)
            qr = action.fetch_qrcode()

            if qr["is_logged_in"]:
                save_browser_cookies(context)
                logger.info("Already logged in — cookies saved")
                return {"success": True, "message": "已经登录，cookies 已保存"}

            success = action.wait_for_login(timeout)
            if success:
                return {"success": True, "message": "登录成功"}
            return {"success": False, "message": "登录超时或二维码已失效"}

    def check_login_status(self, headless: bool = True) -> dict:
        """Check if currently logged in."""
        if get_cdp_url():
            from browser.native_cdp import NativeBossSession
            with NativeBossSession() as session:
                return session.status()
        with create_browser(headless=headless) as (browser, context, page):
            if get_cdp_url():
                action = LoginAction(page, context)
                action._check_page()
                logged_in = action._is_authenticated()
                return {"logged_in": logged_in, "username": None,
                        "message": "已连接专用 Chrome；未识别用户标识时请人工核实登录状态"}
            action = CheckLoginAction(page)
            return action.check()

    # --- Search ---

    def search_jobs(self, keyword: str, city: str = "全国", experience: str = "",
                    education: str = "", salary: str = "", limit: int = 20,
                    headless: bool = True) -> list[dict]:
        """Search jobs on Boss直聘."""
        if not keyword.strip() or not 1 <= limit <= 100:
            raise ValueError("关键词不能为空，limit 必须在 1 到 100 之间")
        if get_cdp_url():
            from browser.native_cdp import NativeBossSession
            with NativeBossSession() as session:
                results = session.search(keyword, city, experience, education, salary, limit)
            if results:
                self._save_search_results_md(keyword, city, results)
            return results
        with create_browser(headless=headless) as (browser, context, page):
            action = JobSearchAction(page)
            results = action.search(keyword, city, experience, education, salary, limit)

        # Save results as markdown
        if results:
            self._save_search_results_md(keyword, city, results)

        return results

    # --- Job Detail ---

    def get_job_detail(self, url: str, headless: bool = True) -> dict:
        """Get job detail from URL."""
        self._validate_job_url(url)
        if get_cdp_url():
            from browser.native_cdp import NativeBossSession
            with NativeBossSession() as session:
                detail = session.detail(url)
            analysis = AnalyzeJobAction(None).analyze(detail)
            self._save_job_detail_md(detail, analysis)
            return {"detail": detail, "analysis": analysis}
        with create_browser(headless=headless) as (browser, context, page):
            detail_action = JobDetailAction(page)
            detail = detail_action.get_detail(url)
            analyze_action = AnalyzeJobAction(page)
            analysis = analyze_action.analyze(detail)

        # Save as markdown
        if detail.get("title"):
            self._save_job_detail_md(detail, analysis)

        return {"detail": detail, "analysis": analysis}

    # --- Apply ---

    def apply_job(self, url: str, message: str = "",
                  headless: bool = True) -> dict:
        """Apply to a job."""
        if get_cdp_url():
            return {"success": False, "status": "manual_action_required",
                    "message": "原生会话模式仅验证读取功能；请在浏览器手动投递。"}
        self._validate_job_url(url)
        with create_browser(headless=headless) as (browser, context, page):
            action = ApplyJobAction(page, context)
            return action.apply(url, message)

    # --- Resume Advice ---

    def resume_advice(self, job_detail: dict, resume_text: str = "") -> dict:
        """Provide resume writing/modification advice based on job requirements.

        This method extracts key requirements from the job and generates advice.
        The actual AI analysis should be done by the calling agent.
        """
        analysis = AnalyzeJobAction(None).analyze(job_detail) if isinstance(job_detail, dict) else {}

        return {
            "job_title": analysis.get("title", ""),
            "required_tech": analysis.get("tech_stack", []),
            "experience_required": analysis.get("experience_required", ""),
            "education_required": analysis.get("education_required", ""),
            "full_description": analysis.get("full_description", ""),
            "resume_text": resume_text,
            "advice_hint": "请根据以上岗位要求，对比简历内容提供修改建议",
        }

    # --- Save helpers ---

    def _save_search_results_md(self, keyword: str, city: str, results: list[dict]) -> Path:
        """Save search results to markdown."""
        from local_paths import data_root
        output_dir = data_root() / 'search_results'
        output_dir.mkdir(exist_ok=True)

        ts = time.strftime("%Y%m%d_%H%M%S")
        safe_name = self._sanitize_filename(f"{keyword}_{city}", 40)
        filepath = output_dir / f"{safe_name}_{ts}.md"

        lines = [
            f"# Boss直聘搜索结果: {keyword} ({city})\n",
            f"> 搜索时间: {time.strftime('%Y-%m-%d %H:%M:%S')}  \n",
            f"> 共 {len(results)} 条结果\n",
            "---\n",
        ]

        for i, job in enumerate(results, 1):
            lines.append(f"## {i}. {job.get('title', '未知岗位')}\n")
            if job.get("company"):
                lines.append(f"**公司**: {job['company']}  ")
            if job.get("salary"):
                lines.append(f"**薪资**: {job['salary']}  ")
            if job.get("location"):
                lines.append(f"**地点**: {job['location']}  ")
            if job.get("tags"):
                lines.append(f"**要求**: {job['tags']}  ")
            if job.get("link"):
                lines.append(f"\n**链接**: [{job['link']}]({job['link']})  ")
            lines.append("\n---\n")

        filepath.write_text("\n".join(lines), encoding="utf-8")
        logger.info(f"Search results saved to {filepath}")
        return filepath

    def _save_job_detail_md(self, detail: dict, analysis: dict) -> Path:
        """Save job detail to markdown."""
        from local_paths import data_root
        output_dir = data_root() / 'search_results'
        output_dir.mkdir(exist_ok=True)

        title = detail.get("title", "未知岗位")
        ts = time.strftime("%Y%m%d_%H%M%S")
        safe_title = self._sanitize_filename(title, 50)
        filepath = output_dir / f"{safe_title}_{ts}.md"

        lines = [
            f"# {title}\n",
            f"**公司**: {detail.get('company', '')}  ",
            f"**薪资**: {detail.get('salary', '')}  ",
            f"**地点**: {detail.get('location', '')}  ",
            f"**要求**: {detail.get('tags', '')}  ",
            f"**HR**: {detail.get('hr_name', '')} {detail.get('hr_title', '')}  ",
        ]
        if detail.get("url"):
            lines.append(f"**链接**: [{detail['url']}]({detail['url']})  ")
        lines.append(f"\n**获取时间**: {time.strftime('%Y-%m-%d %H:%M:%S')}  ")
        lines.append("\n---\n")

        lines.append("## 岗位描述\n")
        lines.append(f"{detail.get('description', '')}\n")

        if analysis.get("tech_stack"):
            lines.append("\n## 技术栈要求\n")
            lines.append(", ".join(analysis["tech_stack"]) + "\n")

        lines.append("\n## 公司信息\n")
        lines.append(f"{detail.get('company_info', '')}\n")
        lines.append(f"{detail.get('company_detail', '')}\n")

        filepath.write_text("\n".join(lines), encoding="utf-8")
        logger.info(f"Job detail saved to {filepath}")
        return filepath
