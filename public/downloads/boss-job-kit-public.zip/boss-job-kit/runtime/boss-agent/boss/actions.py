"""Browser automation actions for Boss直聘 (zhipin.com).

Each action class encapsulates a specific workflow.
"""

from __future__ import annotations

import sys
import base64
import time
from pathlib import Path
from urllib.parse import urlsplit

# 确保项目根目录在 sys.path 中
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from loguru import logger
from playwright.sync_api import Page, BrowserContext, TimeoutError as PwTimeout

from browser.manager import BOSS_BASE_URL, save_browser_cookies


# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------

class LoginAction:
    """Handle Boss直聘 login via QR code scanning."""

    LOGIN_URL = f"{BOSS_BASE_URL}/web/user/?ka=header-login"

    def __init__(self, page: Page, context: BrowserContext):
        self.page = page
        self.context = context

    def _check_page(self) -> None:
        if self.page.is_closed():
            raise RuntimeError("登录窗口已关闭，请重新运行登录脚本。")
        if self.page.url in ("about:blank", "about:srcdoc"):
            raise RuntimeError(
                "Boss 登录页跳转到了空白页，尚未登录。请先用普通 Chrome 打开 "
                "https://www.zhipin.com/web/user/ 对照测试；不要反复重试自动化登录。"
            )

    def _is_authenticated(self) -> bool:
        parsed = urlsplit(self.page.url)
        if parsed.hostname != "www.zhipin.com" or "/web/user" in parsed.path:
            return False
        # Redirects (including verification pages) are not login evidence.
        return self.page.locator(
            '.nav-logout, a[href*="/logout"], .header-user-name, .nav-user-name'
        ).count() > 0

    def fetch_qrcode(self) -> dict:
        """Navigate to login page and fetch the QR code.

        Returns:
            dict with keys: qrcode_base64 (str), is_logged_in (bool)
        """
        page = self.page
        page.goto(self.LOGIN_URL, wait_until="domcontentloaded")
        time.sleep(3)

        self._check_page()
        if self._is_authenticated():
            return {"qrcode_base64": "", "is_logged_in": True}

        logger.info(f"Login page loaded: {page.url}")

        # Try to get QR code image
        qr_base64 = ""
        for selector in [
            "img[src*='qrcode']",
            "img[src*='QR']",
            ".qrcode-box img",
            ".login-qrcode img",
            "img[class*='qr']",
            ".scan-login img",
        ]:
            qr_el = page.query_selector(selector)
            if qr_el:
                try:
                    screenshot_bytes = qr_el.screenshot()
                    qr_base64 = base64.b64encode(screenshot_bytes).decode("utf-8")
                    logger.info(f"QR code found with selector: {selector}")
                    break
                except Exception:
                    continue

        if not qr_base64:
            # Fallback: screenshot the whole page
            try:
                page.screenshot(
                    path=str(Path(__file__).parent.parent / "cookies" / "login_qrcode.png"),
                    full_page=False,
                )
                logger.info("Login screenshot saved to cookies/login_qrcode.png")
            except Exception:
                pass

        return {"qrcode_base64": qr_base64, "is_logged_in": False}

    def wait_for_login(self, timeout: int = 240) -> bool:
        """Wait for the user to scan the QR code."""
        page = self.page
        deadline = time.monotonic() + timeout

        while time.monotonic() < deadline:
            self._check_page()
            if self._is_authenticated():
                logger.info("Login successful!")
                save_browser_cookies(self.context)
                return True
            # Keep the session open for manual QR refresh or SMS login.
            page.wait_for_timeout(1000)

        logger.warning("Login wait timed out")
        return False


# ---------------------------------------------------------------------------
# Check Login Status
# ---------------------------------------------------------------------------

class CheckLoginAction:
    """Check if the current session is logged in."""

    def __init__(self, page: Page):
        self.page = page

    def check(self) -> dict:
        """Visit Boss直聘 and check login status."""
        page = self.page
        page.goto(BOSS_BASE_URL, wait_until="domcontentloaded")
        time.sleep(2)

        # Check for login button
        login_btn = page.query_selector(
            'a:has-text("登录"), a:has-text("注册"), '
            'a[href*="/web/user"]'
        )
        if login_btn:
            text = login_btn.inner_text().strip()
            if "登录" in text or "注册" in text:
                logger.info("Not logged in — login button found")
                return {"logged_in": False, "username": None}

        # Check for user menu
        user_menu = page.query_selector(
            '.user-nav, .header-user-info, '
            'a[href*="/web/geek"], .nav-user'
        )
        if user_menu:
            username_el = page.query_selector(
                '.user-name, .header-user-name, .nav-user-name'
            )
            username = username_el.inner_text().strip() if username_el else "已登录用户"
            logger.info(f"Logged in as: {username}")
            return {"logged_in": True, "username": username}

        logger.info("Not logged in")
        return {"logged_in": False, "username": None}


# ---------------------------------------------------------------------------
# Job Search
# ---------------------------------------------------------------------------

class JobSearchAction:
    """Search jobs on Boss直聘."""

    def __init__(self, page: Page):
        self.page = page

    def _is_security_page(self) -> bool:
        """Check if current page is a security verification page."""
        url = self.page.url
        if "_security_check" in url:
            return True
        try:
            body_text = self.page.inner_text("body")
            if "安全验证" in body_text or "请按住滑块" in body_text:
                return True
        except Exception:
            pass
        return False

    def _solve_slider_captcha(self) -> bool:
        """Attempt to solve the slider captcha by dragging the slider to the right.

        Returns:
            True if the slider was found and dragged, False otherwise.
        """
        raise RuntimeError("需要人工完成 Boss 安全验证；停止自动重试，请在浏览器登录后再试")

    def search(self, keyword: str, city: str = "全国", experience: str = "",
               education: str = "", salary: str = "", limit: int = 20) -> list[dict]:
        """Search jobs by interacting with the Boss直聘 web UI via Playwright.

        Args:
            keyword: job keyword (e.g. "Python开发")
            city: city name or "全国"
            experience: experience requirement (e.g. "1-3年", "3-5年", "5-10年", "经验不限")
            education: education requirement (e.g. "本科", "硕士", "大专", "学历不限")
            salary: salary range (e.g. "15-25k", "25-50k", "50k以上")
            limit: max results

        Returns:
            list of job dicts
        """
        page = self.page

        # Step 1: Go to homepage
        logger.info("Navigating to Boss直聘 homepage...")
        page.goto(BOSS_BASE_URL, wait_until="domcontentloaded")
        time.sleep(2)

        # Handle security check
        if self._is_security_page():
            logger.warning("Security page on homepage, trying to solve...")
            self._solve_slider_captcha()
            time.sleep(3)
            if self._is_security_page():
                logger.error("Security verification blocked, cannot search")
                return []

        # Step 2: Find and fill the search input
        search_input = (
            page.query_selector("input[name='query']")
            or page.query_selector("input.search-input")
            or page.query_selector(".search-box input")
            or page.query_selector("input[placeholder*='搜索']")
            or page.query_selector("input[placeholder*='职位']")
            or page.query_selector("#searchInput")
            or page.query_selector("input.ipt-search")
        )

        if not search_input:
            logger.warning("Could not find search input, falling back to URL navigation")
            return self._search_by_url(keyword, city, experience, education, limit)

        logger.info(f"Found search input, typing keyword: {keyword}")
        search_input.click()
        time.sleep(0.3)
        search_input.fill("")
        time.sleep(0.2)
        search_input.type(keyword, delay=50)  # human-like typing speed
        time.sleep(1)

        # Step 3: Click the search button or press Enter
        search_btn = (
            page.query_selector("button.btn-search")
            or page.query_selector("button.btn.btn-search")
            or page.query_selector(".search-form button")
            or page.query_selector("button[type='submit']")
        )

        if search_btn:
            logger.info(f"Clicking search button: {search_btn.get_attribute('class')}")
            search_btn.click()
        else:
            logger.info("No search button found, pressing Enter...")
            search_input.press("Enter")

        time.sleep(3)
        page.wait_for_load_state("domcontentloaded")

        # Check security page again after search
        if self._is_security_page():
            logger.warning("Security page after search, trying to solve...")
            self._solve_slider_captcha()
            time.sleep(3)
            if self._is_security_page():
                logger.error("Security verification blocked search results")
                return []

        # Step 4: Apply city filter (if not 全国)
        if city and city != "全国":
            self._apply_city_filter(city)

        # Step 5: Apply experience filter
        if experience:
            self._apply_text_filter("经验", experience)

        # Step 6: Apply education filter
        if education:
            self._apply_text_filter("学历", education)

        # Step 7: Apply salary filter
        if salary:
            self._apply_text_filter("薪资", salary)

        time.sleep(2)

        # Step 8: Scroll to load more results
        for _ in range(3):
            page.mouse.wheel(0, 800)
            time.sleep(1)

        # Debug screenshot
        debug_dir = Path(__file__).parent.parent / "cookies"
        try:
            page.screenshot(path=str(debug_dir / "search_debug.png"), full_page=False)
            logger.info(f"Search page URL: {page.url}")
        except Exception:
            pass

        # Step 9: Parse job cards
        results = []
        for selector in [".job-card-box", ".job-card-wrapper", ".job-list li", ".search-job-result .job-card-body", ".job-card"]:
            items = page.query_selector_all(selector)
            if items:
                logger.info(f"Found {len(items)} jobs with selector: {selector}")
                for item in items[:limit]:
                    try:
                        job = self._parse_job_card(item)
                        if job:
                            results.append(job)
                    except Exception as e:
                        logger.debug(f"Failed to parse job: {e}")
                        continue
                break

        # Fallback: extract from links
        if not results:
            results = self._fallback_parse(page, limit)

        logger.info(f"Search '{keyword}' returned {len(results)} jobs")
        return results

    def _search_by_url(self, keyword: str, city: str, experience: str,
                       education: str, limit: int) -> list[dict]:
        """Fallback: navigate directly to search URL."""
        page = self.page
        city_codes = {
            "全国": "100010000", "北京": "101010100", "上海": "101020100",
            "广州": "101280100", "深圳": "101280600", "杭州": "101210100",
            "成都": "101270100", "南京": "101190100", "武汉": "101200100",
            "西安": "101110100", "苏州": "101190400", "长沙": "101250100",
        }
        city_code = city_codes.get(city, "100010000")
        search_url = f"{BOSS_BASE_URL}/web/geek/job?query={keyword}&city={city_code}"
        if experience:
            search_url += f"&experience={experience}"
        if education:
            search_url += f"&education={education}"

        logger.info(f"Fallback: navigating to {search_url}")
        page.goto(search_url, wait_until="domcontentloaded")
        time.sleep(3)

        if self._is_security_page():
            self._solve_slider_captcha()
            time.sleep(3)

        for _ in range(3):
            page.mouse.wheel(0, 800)
            time.sleep(1)

        results = []
        for selector in [".job-card-wrapper", ".job-list li", ".search-job-result .job-card-body", ".job-card"]:
            items = page.query_selector_all(selector)
            if items:
                for item in items[:limit]:
                    try:
                        job = self._parse_job_card(item)
                        if job:
                            results.append(job)
                    except Exception:
                        continue
                break
        if not results:
            results = self._fallback_parse(page, limit)
        return results

    def _apply_city_filter(self, city: str) -> None:
        """Click the city filter dropdown and select a city."""
        page = self.page
        try:
            # Click the city selector
            city_btn = (
                page.query_selector(".city-select")
                or page.query_selector("[class*='city'] .dropdown-toggle")
                or page.query_selector("span:has-text('全国')")
                or page.query_selector(".filter-city .dropdown")
            )
            if not city_btn:
                # Try clicking any element that shows "全国" as default city
                city_btn = page.query_selector("text=/全国|选择城市/")
            if city_btn:
                city_btn.click()
                time.sleep(1)

                # Click the target city in the dropdown
                city_option = page.query_selector(f"text=/{city}/")
                if city_option:
                    city_option.click()
                    time.sleep(1)
                    logger.info(f"Applied city filter: {city}")
        except Exception as e:
            logger.debug(f"Failed to apply city filter: {e}")

    def _apply_text_filter(self, filter_name: str, value: str) -> None:
        """Click a filter dropdown and select an option by text."""
        page = self.page
        try:
            # Find the filter button by its label text
            filter_btn = (
                page.query_selector(f"text=/{filter_name}/")
                or page.query_selector(f".filter-item:has-text('{filter_name}')")
                or page.query_selector(f"[class*='filter']:has-text('{filter_name}')")
            )
            if filter_btn:
                filter_btn.click()
                time.sleep(0.8)

                # Click the target option
                option = page.query_selector(f"text=/{value}/")
                if option:
                    option.click()
                    time.sleep(1)
                    logger.info(f"Applied {filter_name} filter: {value}")
        except Exception as e:
            logger.debug(f"Failed to apply {filter_name} filter: {e}")

    def _parse_job_card(self, item) -> dict | None:
        """Parse a single job card."""
        # Job title
        title_el = item.query_selector(
            ".job-name, .job-title, h3 a, .info-primary .job-name"
        )
        title = title_el.inner_text().strip() if title_el else ""
        if not title:
            return None

        # Job link
        link_el = item.query_selector("a.job-name, a[href*='/job_detail']")
        link = ""
        if link_el:
            href = link_el.get_attribute("href") or ""
            if href.startswith("/"):
                link = f"{BOSS_BASE_URL}{href}"
            elif href.startswith("http"):
                link = href

        # Company
        company_el = item.query_selector(
            ".company-name, .company-text a, .info-company .name, .boss-name"
        )
        company = company_el.inner_text().strip() if company_el else ""

        # Salary
        salary_el = item.query_selector(
            ".salary, .job-salary, .job-limit .red, .info-primary .red"
        )
        salary = salary_el.inner_text().strip() if salary_el else ""

        # Location
        location_el = item.query_selector(
            ".job-area, .job-limit .site, .job-info .tag-list span:last-child"
        )
        location = location_el.inner_text().strip() if location_el else ""

        # Experience & Education
        exp_el = item.query_selector(
            ".tag-list, .job-limit .tag-list, .info-primary p, .job-card-footer .tag-list"
        )
        tags = exp_el.inner_text().strip() if exp_el else ""

        # Company info (industry, size)
        company_info_el = item.query_selector(
            ".company-tag-list, .info-company p, .boss-info"
        )
        company_info = company_info_el.inner_text().strip() if company_info_el else ""

        return {
            "title": title,
            "company": company,
            "salary": salary,
            "location": location,
            "tags": tags,
            "company_info": company_info,
            "link": link,
        }

    def _fallback_parse(self, page: Page, limit: int) -> list[dict]:
        """Fallback: parse from links."""
        results = []
        links = page.query_selector_all("a[href*='/job_detail']")
        seen = set()
        for link in links[:limit * 2]:
            try:
                href = link.get_attribute("href") or ""
                if href in seen:
                    continue
                seen.add(href)

                title = link.inner_text().strip()
                if not title or len(title) < 2:
                    continue

                if href.startswith("/"):
                    href = f"{BOSS_BASE_URL}{href}"

                results.append({
                    "title": title[:100],
                    "company": "",
                    "salary": "",
                    "location": "",
                    "tags": "",
                    "company_info": "",
                    "link": href,
                })
                if len(results) >= limit:
                    break
            except Exception:
                continue

        logger.info(f"Fallback parse found {len(results)} jobs")
        return results


# ---------------------------------------------------------------------------
# Job Detail
# ---------------------------------------------------------------------------

class JobDetailAction:
    """Get detailed job information."""

    def __init__(self, page: Page):
        self.page = page

    def get_detail(self, url: str) -> dict:
        """Fetch full job detail page.

        Args:
            url: job detail URL

        Returns:
            job detail dict
        """
        page = self.page
        page.goto(url, wait_until="domcontentloaded")
        time.sleep(2)

        # Title
        title_el = page.query_selector(
            ".name h1, .job-detail-header .job-name, .job-primary .job-name"
        )
        title = title_el.inner_text().strip() if title_el else ""

        # Salary
        salary_el = page.query_selector(
            ".salary, .job-detail-header .salary, .job-primary .red"
        )
        salary = salary_el.inner_text().strip() if salary_el else ""

        # Company
        company_el = page.query_selector(
            ".company-name a, .sider-company .company-name, .job-detail .company-name"
        )
        company = company_el.inner_text().strip() if company_el else ""

        # Location
        location_el = page.query_selector(
            ".job-area, .job-detail-header .job-area"
        )
        location = location_el.inner_text().strip() if location_el else ""

        # Tags (experience, education, etc.)
        tags_el = page.query_selector(
            ".tag-list, .job-detail-header .tag-list, .job-primary .tag-list"
        )
        tags = tags_el.inner_text().strip() if tags_el else ""

        # Job description
        desc_el = page.query_selector(
            ".job-detail-section .job-sec-text, "
            ".detail-bottom-text, .job-detail .text, "
            ".job-sec .text"
        )
        description = desc_el.inner_text().strip() if desc_el else ""

        # Company info
        company_info_el = page.query_selector(
            ".sider-company .company-tag-list, .company-info"
        )
        company_info = company_info_el.inner_text().strip() if company_info_el else ""

        # Company industry & size
        company_detail_el = page.query_selector(
            ".sider-company p, .company-detail"
        )
        company_detail = company_detail_el.inner_text().strip() if company_detail_el else ""

        # HR info
        hr_el = page.query_selector(
            ".sider-userinfo .job-detail-sider-userinfo-name, .boss-info .name"
        )
        hr_name = hr_el.inner_text().strip() if hr_el else ""

        hr_title_el = page.query_selector(
            ".sider-userinfo .boss-info-text, .boss-info .job"
        )
        hr_title = hr_title_el.inner_text().strip() if hr_title_el else ""

        return {
            "title": title,
            "salary": salary,
            "company": company,
            "location": location,
            "tags": tags,
            "description": description,
            "company_info": company_info,
            "company_detail": company_detail,
            "hr_name": hr_name,
            "hr_title": hr_title,
            "url": url,
        }


# ---------------------------------------------------------------------------
# Apply Job
# ---------------------------------------------------------------------------

class ApplyJobAction:
    """Apply to a job on Boss直聘."""

    def __init__(self, page: Page, context: BrowserContext):
        self.page = page
        self.context = context

    def apply(self, url: str, message: str = "") -> dict:
        """Apply to a job by clicking the apply button.

        Args:
            url: job detail URL
            message: optional greeting message to HR

        Returns:
            result dict
        """
        page = self.page
        page.goto(url, wait_until="domcontentloaded")
        time.sleep(2)

        # Click "立即沟通" or "投递简历" button
        apply_btn = None
        for selector in [
            'a:has-text("立即沟通")',
            'button:has-text("立即沟通")',
            'a:has-text("投递简历")',
            'button:has-text("投递简历")',
            '.btn-startchat',
            '.job-detail-header .btn',
        ]:
            apply_btn = page.query_selector(selector)
            if apply_btn:
                logger.info(f"Apply button found: {selector}")
                break

        if not apply_btn:
            return {"success": False, "message": "未找到投递/沟通按钮"}

        # Scroll to button and click
        apply_btn.scroll_into_view_if_needed()
        time.sleep(0.5)

        try:
            apply_btn.evaluate("el => el.click()")
            logger.info("Apply button clicked")
        except Exception:
            apply_btn.click(force=True)

        time.sleep(2)

        # If there's a message dialog, fill in the greeting
        if message:
            msg_input = page.query_selector(
                'textarea[placeholder*="打招呼"], textarea[placeholder*="留言"], '
                '.chat-input textarea, .dialog textarea'
            )
            if msg_input:
                msg_input.fill(message)
                time.sleep(0.5)

                # Click send
                send_btn = page.query_selector(
                    'button:has-text("发送"), button:has-text("确认"), '
                    '.btn-send, .dialog button:has-text("发送")'
                )
                if send_btn:
                    send_btn.click()
                    time.sleep(1)

        save_browser_cookies(self.context)

        # Check for success indicators
        success_indicators = page.query_selector(
            'text=已发送, text=发送成功, text=已投递, .chat-conversation'
        )
        if success_indicators:
            logger.info("Job application successful")
            return {"success": True, "message": "投递/沟通成功"}

        logger.info("Job application completed (status unclear)")
        return {"success": False, "status": "unknown", "message": "未确认投递成功，请人工核实，勿自动重试"}


# ---------------------------------------------------------------------------
# Analyze Job
# ---------------------------------------------------------------------------

class AnalyzeJobAction:
    """Analyze job requirements and provide insights."""

    def __init__(self, page: Page):
        self.page = page

    def analyze(self, job_detail: dict) -> dict:
        """Analyze a job detail and extract structured requirements.

        Args:
            job_detail: dict from JobDetailAction.get_detail()

        Returns:
            analysis dict with extracted requirements
        """
        description = job_detail.get("description", "")
        tags = job_detail.get("tags", "")
        title = job_detail.get("title", "")

        # Extract keywords from description
        tech_keywords = []
        common_techs = [
            "Python", "Java", "Go", "C++", "JavaScript", "TypeScript",
            "React", "Vue", "Angular", "Node.js", "Spring", "Django",
            "MySQL", "PostgreSQL", "MongoDB", "Redis",
            "Docker", "Kubernetes", "K8s",
            "AWS", "Azure", "GCP",
            "机器学习", "深度学习", "NLP", "CV", "大模型", "LLM",
            "TensorFlow", "PyTorch", "Hadoop", "Spark",
            "Linux", "Git", "CI/CD",
        ]
        desc_upper = description.upper()
        for tech in common_techs:
            if tech.upper() in desc_upper or tech in description:
                tech_keywords.append(tech)

        # Parse experience and education from tags
        experience = ""
        education = ""
        for tag in tags.split("\n"):
            tag = tag.strip()
            if "年" in tag or "经验" in tag:
                experience = tag
            elif tag in ["本科", "硕士", "博士", "大专", "学历不限"]:
                education = tag

        return {
            "title": title,
            "salary": job_detail.get("salary", ""),
            "company": job_detail.get("company", ""),
            "location": job_detail.get("location", ""),
            "experience_required": experience,
            "education_required": education,
            "tech_stack": tech_keywords,
            "full_description": description,
            "hr_name": job_detail.get("hr_name", ""),
            "hr_title": job_detail.get("hr_title", ""),
        }
