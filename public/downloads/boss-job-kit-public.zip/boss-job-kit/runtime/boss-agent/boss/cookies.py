"""Cookie management for persisting Boss直聘 login sessions."""

from __future__ import annotations

import json
import os
from pathlib import Path

from loguru import logger


def get_cookies_dir() -> Path:
    """Get the cookies directory, creating it if needed."""
    from local_paths import data_root
    cookies_dir = data_root() / 'cookies'
    cookies_dir.mkdir(parents=True, exist_ok=True)
    return cookies_dir


def get_cookies_path() -> Path:
    """Get the path to the cookies file."""
    return get_cookies_dir() / "cookies.json"


def load_cookies() -> list[dict] | None:
    """Load cookies from disk."""
    path = get_cookies_path()
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        logger.info(f"Loaded {len(data)} cookies from {path}")
        return data
    except (json.JSONDecodeError, OSError) as e:
        logger.warning(f"Failed to load cookies: {e}")
        return None


def save_cookies(cookies: list[dict]) -> None:
    """Save cookies to disk."""
    path = get_cookies_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(cookies, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)
    logger.info(f"Saved {len(cookies)} cookies to {path}")


def delete_cookies() -> bool:
    """Delete the cookies file."""
    path = get_cookies_path()
    if path.exists():
        path.unlink()
        logger.info(f"Deleted cookies at {path}")
        return True
    return False
