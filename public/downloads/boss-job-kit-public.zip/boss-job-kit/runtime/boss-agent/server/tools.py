"""MCP tool definitions for boss-mcp."""

from __future__ import annotations

import asyncio
from functools import wraps
from fastmcp import FastMCP

_browser_lock = asyncio.Lock()

def threaded(fn):
    """Keep synchronous Playwright off the MCP asyncio event loop."""
    @wraps(fn)
    async def run(*args, **kwargs):
        async with _browser_lock:
            return await asyncio.to_thread(fn, *args, **kwargs)
    return run

from boss.service import BossService
from boss.cookies import delete_cookies as _delete_cookies



def create_mcp_server(headless: bool = True) -> FastMCP:
    """Create and configure the FastMCP server with all Boss直聘 tools."""

    mcp = FastMCP("boss-mcp", version="1.0.0")
    svc = BossService()

    @mcp.tool(description="离线检查安装与浏览器状态，不联网、不暴露 Cookie 内容。")
    @threaded
    def health_check() -> dict:
        from pathlib import Path
        from importlib.metadata import version
        from playwright.sync_api import sync_playwright
        from boss.cookies import get_cookies_path
        from browser.manager import get_cdp_url
        from login_native import chrome_path
        try:
            browser_installed = chrome_path().is_file()
        except RuntimeError:
            browser_installed = False
        try:
            cdp_present = bool(get_cdp_url())
        except RuntimeError:
            cdp_present = False
        return {"ready": browser_installed, "browser_installed": browser_installed,
                "browser_mode": "native_cdp", "session_registered": cdp_present,
                "connection_tested": False,
                "cookies_present": get_cookies_path().is_file(),
                "fastmcp_version": version("fastmcp"), "headless": headless}

    # ------------------------------------------------------------------
    # 1. Login & Auth
    # ------------------------------------------------------------------

    @mcp.tool(description="检查 Boss直聘 登录状态。无参数，直接调用即可。")
    @threaded
    def check_login_status() -> dict:
        """Check Boss直聘 login status."""
        return svc.check_login_status(headless=headless)

    @mcp.tool(description="删除 cookies 文件，重置登录状态。删除后需要重新扫码登录。")
    @threaded
    def delete_cookies() -> dict:
        """Delete saved cookies."""
        deleted = _delete_cookies()
        if deleted:
            return {"success": True, "message": "Cookies 已删除，请重新登录"}
        return {"success": False, "message": "没有找到 cookies 文件"}

    # ------------------------------------------------------------------
    # 2. Job Search
    # ------------------------------------------------------------------

    @mcp.tool(
        description=(
            "搜索 Boss直聘 岗位。参数："
            "keyword（搜索关键词，必填，如 'Python开发'）、"
            "city（城市，默认 '全国'，支持：北京/上海/广州/深圳/杭州/成都/南京/武汉/西安/苏州/长沙）、"
            "experience（经验要求，可选，如 '1-3年'/'3-5年'/'经验不限'）、"
            "education（学历要求，可选，如 '本科'/'硕士'/'学历不限'）、"
            "salary（薪资范围，可选）、"
            "limit（最大结果数，默认 20）。"
            "搜索结果自动保存到 search_results/ 目录。"
            "原生 Chrome 会话模式已验证关键词和城市；经验、学历、薪资请在页面手动筛选。"
        )
    )
    @threaded
    def search_jobs(
        keyword: str,
        city: str = "全国",
        experience: str = "",
        education: str = "",
        salary: str = "",
        limit: int = 20,
    ) -> list[dict]:
        """Search jobs on Boss直聘."""
        return svc.search_jobs(keyword, city, experience, education, salary, limit, headless=headless)

    # ------------------------------------------------------------------
    # 3. Job Detail + Analysis
    # ------------------------------------------------------------------

    @mcp.tool(
        description=(
            "获取 Boss直聘 岗位详情（包含岗位描述、公司信息、技术栈分析）。参数："
            "url（岗位详情页完整 URL，必填，从搜索结果获取）。"
            "返回详情 dict，包含 detail（原始信息）和 analysis（结构化分析：技术栈、经验/学历要求等）。"
            "结果自动保存到 search_results/ 目录。"
        )
    )
    @threaded
    def get_job_detail(url: str) -> dict:
        """Get job detail with analysis."""
        return svc.get_job_detail(url, headless=headless)

    # ------------------------------------------------------------------
    # 4. Apply Job
    # ------------------------------------------------------------------

    @mcp.tool(
        description=(
            "投递/沟通 Boss直聘 岗位（点击立即沟通按钮）。参数："
            "url（岗位详情页完整 URL，必填）、"
            "message（打招呼消息，可选）。"
            "通用发行版禁用此直接发送入口；请使用 scripts/kit.py send 的预检、当次授权和核验流程。"
        )
    )
    @threaded
    def apply_job(url: str, message: str = "", confirmed: bool = False) -> dict:
        """Apply to a job on Boss直聘."""
        return {"success": False, "status": "disabled",
                "message": "Use scripts/kit.py send with a prepared plan and current user authorization."}

    # ------------------------------------------------------------------
    # 5. Resume Advice
    # ------------------------------------------------------------------

    @mcp.tool(
        description=(
            "根据岗位要求提供简历撰写/修改建议。参数："
            "job_url（岗位详情页 URL，必填）、"
            "resume_text（简历内容文本，可选，提供后可给出更精准的对比建议）。"
            "该工具提取岗位关键要求，供 AI 分析后给出简历优化建议。"
        )
    )
    @threaded
    def resume_advice(job_url: str, resume_text: str = "") -> dict:
        """Get resume advice based on job requirements."""
        detail = svc.get_job_detail(job_url, headless=headless)
        return svc.resume_advice(detail.get("detail", {}), resume_text)

    return mcp
