"""Require the package launcher to bind an isolated data directory."""
import os
from pathlib import Path


def data_root():
    value = os.environ.get('BOSS_DATA_DIR')
    if not value:
        raise RuntimeError('Start through scripts/kit.py; isolated BOSS_DATA_DIR is required')
    path = Path(value).resolve()
    path.mkdir(parents=True, exist_ok=True)
    return path
