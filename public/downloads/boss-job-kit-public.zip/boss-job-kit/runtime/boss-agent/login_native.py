"""Let the user log in before connecting Playwright to dedicated Chrome."""
import json
import os
from pathlib import Path
import socket
import subprocess
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
from local_paths import data_root
SESSION = data_root() / '.browser-session.json'


def chrome_path():
    candidates = [Path(os.environ.get("PROGRAMFILES", "C:/Program Files")) / "Google/Chrome/Application/chrome.exe",
                  Path(os.environ.get("LOCALAPPDATA", "")) / "Google/Chrome/Application/chrome.exe"]
    for path in candidates:
        if path.is_file():
            return path
    raise RuntimeError("没有找到系统 Chrome，请先安装 Chrome。")


def start():
    # Reuse the dedicated browser if still running, without attaching Playwright.
    if SESSION.exists():
        endpoint = json.loads(SESSION.read_text(encoding="utf-8"))["endpoint"]
        from browser.manager import get_cdp_url
        get_cdp_url()  # Validate local-only endpoint before requesting it.
        try:
            with urllib.request.urlopen(endpoint + "/json/version", timeout=2):
                return endpoint
        except OSError:
            pass
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    endpoint = f"http://127.0.0.1:{port}"
    subprocess.Popen([str(chrome_path()),
                      f"--user-data-dir={data_root() / 'chrome-profile'}",
                      "--remote-debugging-address=127.0.0.1",
                      f"--remote-debugging-port={port}",
                      "--no-first-run", "--no-default-browser-check",
                      "https://www.zhipin.com/web/user/?ka=header-login"])
    for _ in range(40):
        try:
            with urllib.request.urlopen(endpoint + "/json/version", timeout=1):
                break
        except OSError:
            time.sleep(.25)
    else:
        raise RuntimeError("Chrome 启动失败；若专用窗口已打开，请先关闭后重试。")
    return endpoint


def main():
    endpoint = start()
    print("请在专用 Chrome 中完成登录；此时尚未接管页面。")
    print("看到登录后的个人页面后，再回到这里按 Enter。不要在登录前调用 MCP。")
    input()
    # Persist endpoint only after manual login; do not auto-connect during login.
    SESSION.write_text(json.dumps({"endpoint": endpoint}), encoding="utf-8")
    print("会话已登记。保持 Chrome 窗口打开，即可使用 boss-agent。")
    print("这里只登记连接；登录状态与岗位读取需要下一次 MCP 调用验证。")


if __name__ == "__main__":
    try:
        main()
    except (Exception, KeyboardInterrupt) as exc:
        print(f"登录准备未完成：{exc}")
        raise SystemExit(1)
