"""Browser management for Playwright-based automation."""

from __future__ import annotations

import sys
import os
import json
from urllib.parse import urlsplit
from pathlib import Path
from contextlib import contextmanager
from typing import Generator

# 确保项目根目录在 sys.path 中
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if (_PROJECT_ROOT / ".browsers").is_dir():
    os.environ.setdefault("PLAYWRIGHT_BROWSERS_PATH", str(_PROJECT_ROOT / ".browsers"))
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from loguru import logger
from playwright.sync_api import sync_playwright, Browser, BrowserContext, Page

from boss.cookies import load_cookies, save_cookies


BOSS_BASE_URL = "https://www.zhipin.com"
from local_paths import data_root
SESSION_FILE = data_root() / '.browser-session.json'


def get_cdp_url() -> str:
    endpoint = ""
    if not endpoint and SESSION_FILE.exists():
        endpoint = json.loads(SESSION_FILE.read_text(encoding="utf-8"))["endpoint"]
    if endpoint:
        parsed = urlsplit(endpoint)
        if (parsed.scheme != "http" or parsed.hostname != "127.0.0.1"
                or not parsed.port or parsed.username or parsed.password
                or parsed.path not in ("", "/") or parsed.query or parsed.fragment):
            raise ValueError("CDP endpoint must be http://127.0.0.1:<port>")
    if not endpoint:
        raise RuntimeError('Run kit.py login and complete your own dedicated Chrome login first')
    return endpoint


@contextmanager
def create_browser(headless: bool = True) -> Generator[tuple[Browser, BrowserContext, Page], None, None]:
    """Create a browser instance with cookies loaded.

    Yields:
        (browser, context, page) tuple
    """
    proxy = os.environ.get("BOSS_PROXY")

    with sync_playwright() as p:
        endpoint = get_cdp_url()
        if endpoint:
            browser = p.chromium.connect_over_cdp(endpoint, timeout=10000)
            context = browser.contexts[0]
            page = next((page for page in context.pages
                         if urlsplit(page.url).hostname == "www.zhipin.com"), None)
            if page is None:
                raise RuntimeError("请在专用 Chrome 窗口打开 Boss 页面后再调用工具。")
            # The user owns this browser and its tabs. Playwright.stop only disconnects.
            yield browser, context, page
            return
        # Use the browser's native identity and APIs; do not patch website globals.
        channel = os.environ.get("BOSS_BROWSER_CHANNEL", "chromium")
        launch_options = {"headless": headless}
        if channel != "chromium":
            if channel not in ("chrome", "msedge"):
                raise ValueError("BOSS_BROWSER_CHANNEL must be chromium, chrome or msedge")
            launch_options["channel"] = channel
        browser = p.chromium.launch(**launch_options)
        context_options: dict = {
            "viewport": {"width": 1440, "height": 900},
            "locale": "zh-CN",
        }

        if proxy:
            context_options["proxy"] = {"server": proxy}
            logger.info("Using proxy for browser")

        context = browser.new_context(**context_options)

        # Load cookies if available
        cookies = load_cookies()
        if cookies:
            context.add_cookies(cookies)
            logger.info(f"Cookies loaded into browser context: {len(cookies)} cookies")
            domains = set(c.get("domain", "") for c in cookies)
            logger.info(f"Cookie domains: {domains}")
        else:
            logger.warning("No cookies found — please run login.py first")

        page = context.new_page()
        page.set_default_timeout(30000)

        try:
            yield browser, context, page
        finally:
            page.close()
            context.close()
            browser.close()
            logger.debug("Browser closed")


def save_browser_cookies(context: BrowserContext) -> None:
    """Save cookies from browser context to disk."""
    cookies = context.cookies([BOSS_BASE_URL])
    save_cookies(cookies)
