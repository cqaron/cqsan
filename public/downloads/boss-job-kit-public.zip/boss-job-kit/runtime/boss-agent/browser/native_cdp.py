"""Small synchronous CDP client for the user's dedicated Boss tab."""
import json
import time
import urllib.request
from urllib.parse import urlsplit, urlencode
from websockets.sync.client import connect
from browser.manager import get_cdp_url


class NativeBossSession:
    def __enter__(self):
        endpoint = get_cdp_url()
        if not endpoint:
            raise RuntimeError("请先运行 scripts/kit.py login 登记专用 Chrome。")
        with urllib.request.urlopen(endpoint + "/json/list", timeout=5) as response:
            tabs = json.load(response)
        tab = next((t for t in tabs if t.get("type") == "page"
                    and urlsplit(t.get("url", "")).hostname == "www.zhipin.com"), None)
        if not tab:
            raise RuntimeError("专用 Chrome 中没有 Boss 页面。")
        socket_url = tab["webSocketDebuggerUrl"]
        if urlsplit(socket_url).hostname != "127.0.0.1":
            raise ValueError("CDP websocket must be local")
        self.ws = connect(socket_url, open_timeout=5, max_size=4*1024*1024)
        self.sequence = 0
        return self

    def __exit__(self, *args):
        self.ws.close()  # Disconnect only. Never close the user's tab/browser.

    def call(self, method, params=None):
        self.sequence += 1
        self.ws.send(json.dumps({"id": self.sequence, "method": method, "params": params or {}}))
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            reply = json.loads(self.ws.recv(timeout=max(.1, deadline-time.monotonic())))
            if reply.get("id") == self.sequence:
                if "error" in reply:
                    raise RuntimeError(reply["error"].get("message", "CDP error"))
                return reply.get("result", {})
        raise TimeoutError("Chrome 响应超时")

    def evaluate(self, expression):
        result = self.call("Runtime.evaluate", {"expression": expression, "returnByValue": True})
        if result.get("exceptionDetails"):
            raise RuntimeError("页面读取失败，请检查专用 Chrome 页面。")
        return result.get("result", {}).get("value")

    def wait_page(self):
        deadline = time.monotonic()+20
        while time.monotonic() < deadline:
            result = self.evaluate("({url:location.href, length:document.body?.innerText.length || 0, ready:document.readyState})")
            if result and result["length"] > 20 and result["ready"] == "complete":
                if "_security_check" in result["url"]:
                    raise RuntimeError("页面要求人工验证，请在专用 Chrome 中完成后再试。")
                return
            time.sleep(.5)
        raise RuntimeError("页面正文未加载，请在专用 Chrome 检查页面；没有自动重复刷新。")

    def navigate(self, url):
        result = self.call("Page.navigate", {"url": url})
        if result.get("errorText"):
            raise RuntimeError(result["errorText"])
        time.sleep(1)
        self.wait_page()

    def status(self):
        return self.evaluate('''(() => {
            const visible = s => [...document.querySelectorAll(s)].some(x => !!(x.offsetWidth || x.offsetHeight));
            const rendered = (document.body?.innerText.length || 0) > 20;
            const logout = !!document.querySelector('.link-logout, .nav-logout, a[href*="/logout"]');
            return {logged_in: rendered && visible('.user-nav') && logout,
                    page_rendered: rendered, browser_mode:'native_cdp',
                    evidence:'visible user menu with logout control', url:location.origin+location.pathname};
        })()''')

    def search(self, keyword, city, experience, education, salary, limit):
        cities = {"全国":"100010000", "北京":"101010100", "上海":"101020100",
                  "广州":"101280100", "深圳":"101280600", "杭州":"101210100",
                  "成都":"101270100", "南京":"101190100", "武汉":"101200100",
                  "西安":"101110100", "苏州":"101190400", "长沙":"101250100"}
        if city not in cities:
            raise ValueError("不支持的城市，请选择工具说明中的城市。")
        # Do not silently pretend unsupported filters were applied.
        if experience or education or salary:
            raise ValueError("当前原生会话模式仅验证关键词和城市搜索；经验、学历、薪资请在页面手动筛选。")
        self.navigate("https://www.zhipin.com/web/geek/jobs?" + urlencode({"query":keyword,"city":cities[city]}))
        deadline=time.monotonic()+20
        while time.monotonic()<deadline:
            results=self.evaluate('''(() => {
                const text=(el,s) => el.querySelector(s)?.innerText.trim() || '';
                const seen=new Set();
                return [...document.querySelectorAll('a[href*="/job_detail/"]')].map(a => {
                    const el=a.closest('.job-card-wrap, .job-card-box, .job-card-wrapper') || a.closest('li');
                    if(!el)return null;
                    const link=a.href;
                    return {title:a.innerText.trim().split(String.fromCharCode(10))[0], company:text(el,'.company-name, .boss-name'),
                            salary:text(el,'.salary, .job-salary'), location:text(el,'.job-area, .company-location'),
                            tags:text(el,'.tag-list'), company_info:text(el,'.company-tag-list'), link};
                }).filter(j => j && j.title && j.link && !seen.has(j.link) && seen.add(j.link));
            })()''')
            if results:
                return results[:limit]
            time.sleep(.5)
        raise RuntimeError("没有识别到岗位卡片，可能无结果或页面结构变化；请检查浏览器，不自动当作搜索成功。")

    def detail(self, url):
        self.navigate(url)
        deadline=time.monotonic()+10
        while time.monotonic()<deadline:
            detail=self.evaluate('''(() => {
                const text=s=>document.querySelector(s)?.innerText.trim() || '';
                return {title:text('.name h1, .job-detail-header .job-name, .job-primary .job-name'),
                        salary:text('.salary, .job-primary .red'), company:text('.company-name a, .sider-company .company-name'),
                        location:text('.job-area, .job-location'), tags:text('.job-primary .text, .tag-list'),
                        description:text('.job-sec-text, .job-sec .text, .detail-bottom-text'),
                        company_info:text('.sider-company .company-tag-list, .company-info'), url:location.href};
            })()''')
            if detail.get("title") and detail.get("description"):
                return detail
            time.sleep(.5)
        raise RuntimeError("未读到完整岗位标题和 JD，请检查登录、验证或下架提示。")
